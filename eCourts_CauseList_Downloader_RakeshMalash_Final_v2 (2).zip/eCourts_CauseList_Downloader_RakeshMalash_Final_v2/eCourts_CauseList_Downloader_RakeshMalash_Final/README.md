# 🏛️ eCourts Cause List Downloader — Rakesh Malash

This Streamlit app downloads all judges' cause list PDFs from  
[https://newdelhi.dcourts.gov.in/cause-list-%e2%81%84-daily-board/](https://newdelhi.dcourts.gov.in/cause-list-%e2%81%84-daily-board/)

## ⚙️ How to Run
1. Extract the ZIP file  
2. Open a terminal in the folder  
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run the Streamlit app:
   ```bash
   streamlit run app.py
   ```
5. Select a date and click **“Download All Cause Lists”**  
   PDFs will be saved inside `/output/`, and a ZIP will be created automatically.

## 📂 Output Example
```
output/
 ├── Judge_1_15-10-2025.pdf
 ├── Judge_2_15-10-2025.pdf
 └── cause_lists.zip
```

## 🧑‍💻 Author
**Rakesh Malash** — B.Tech CSE, College of Engineering and Management, Kolaghat
