import os
import requests
from bs4 import BeautifulSoup

BASE_URL = "https://newdelhi.dcourts.gov.in/cause-list-%e2%81%84-daily-board/"

def download_cause_lists(date_obj, output_folder):
    date_str = date_obj.strftime("%d-%m-%Y")
    response = requests.get(BASE_URL, timeout=20)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")

    pdf_links = []
    for link in soup.find_all("a", href=True):
        href = link["href"]
        if href.endswith(".pdf"):
            pdf_links.append(href)

    saved_files = []
    for i, pdf_url in enumerate(pdf_links, 1):
        try:
            pdf_name = f"Judge_{i}_{date_str}.pdf"
            pdf_path = os.path.join(output_folder, pdf_name)
            file_data = requests.get(pdf_url, timeout=15)
            with open(pdf_path, "wb") as f:
                f.write(file_data.content)
            saved_files.append(pdf_path)
        except Exception as e:
            print(f"Error downloading {pdf_url}: {e}")
            continue
    return saved_files
