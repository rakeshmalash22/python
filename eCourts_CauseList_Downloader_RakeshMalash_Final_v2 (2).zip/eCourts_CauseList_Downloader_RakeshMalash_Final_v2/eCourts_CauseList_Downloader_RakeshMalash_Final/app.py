import streamlit as st
from scraper import download_cause_lists
from utils import make_zip
import os
import datetime

st.set_page_config(page_title="eCourts Cause List Downloader", layout="centered")

st.title("🏛️ eCourts Cause List Downloader (New Delhi Courts)")
st.markdown("### Download all judges' cause lists (PDF) for a selected date.")

selected_date = st.date_input("Select Date", datetime.date.today())
download_button = st.button("Download All Cause Lists")

output_folder = "output"
os.makedirs(output_folder, exist_ok=True)

if download_button:
    st.info("Fetching and downloading cause lists... Please wait ⏳")
    try:
        pdf_files = download_cause_lists(selected_date, output_folder)
        if pdf_files:
            zip_path = make_zip(output_folder)
            st.success(f"✅ Download complete! Total PDFs: {len(pdf_files)}")
            with open(zip_path, "rb") as f:
                st.download_button("⬇️ Download All as ZIP", f, file_name=os.path.basename(zip_path))
        else:
            st.warning("No PDFs found for the selected date.")
    except Exception as e:
        st.error(f"❌ Error: {e}")
