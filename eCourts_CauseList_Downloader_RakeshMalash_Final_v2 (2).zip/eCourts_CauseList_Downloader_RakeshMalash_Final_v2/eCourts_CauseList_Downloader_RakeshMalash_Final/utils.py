import zipfile
import os

def make_zip(folder_path):
    zip_path = os.path.join(folder_path, "cause_lists.zip")
    with zipfile.ZipFile(zip_path, "w") as zipf:
        for root, _, files in os.walk(folder_path):
            for file in files:
                if file.endswith(".pdf"):
                    full_path = os.path.join(root, file)
                    zipf.write(full_path, os.path.basename(full_path))
    return zip_path

if __name__ == "__main__":
    folder = r"C:\Users\asus\Downloads\eCourts_CauseList_Downloader_RakeshMalash_Final_v2\eCourts_CauseList_Downloader_RakeshMalash_Final\output"
    zip_file = make_zip(folder)
    print(f"✅ Zip file created: {zip_file}")

