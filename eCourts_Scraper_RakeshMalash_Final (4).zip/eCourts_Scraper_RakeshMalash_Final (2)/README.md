# eCourts Scraper — Cause List to PDF (Final Version)

### 👨‍💻 Author: Rakesh Malash

## 📘 Overview
This tool automatically scrapes **district court cause lists** from [eCourts](https://services.ecourts.gov.in/ecourtindia_v6/),
and saves them as **HTML**, **JSON**, and **PDF**.

### ✅ Features
- Scrape today's or tomorrow's cause list.
- Save cause list in HTML, JSON, and PDF format.
- Automatically formats data for easy review.
- Ready for internship submission (includes PDF output).

## ⚙️ Setup Instructions
1. Install dependencies:
```bash
pip install -r requirements.txt
```
2. Install **wkhtmltopdf** (required for pdfkit PDF generation):
   - Windows: https://wkhtmltopdf.org/downloads.html
   - Add it to system PATH.

## 🚀 Usage
To download today's cause list:
```bash
python ecourt_scraper.py --cnr dummy --today --causelist
```
To download tomorrow's cause list:
```bash
python ecourt_scraper.py --cnr dummy --tomorrow --causelist
```

## 📦 Output
- HTML → `ecourt_output/cause_list_<date>.html`
- JSON → `ecourt_output/cause_list_<date>.json`
- PDF → `ecourt_output/cause_list_<date>.pdf`

## 📤 Submission Guide
- Upload this project to GitHub (public repository).
- Record a short video (1–2 min) showing how it runs.
- Submit **GitHub link** + **Video link** in the internship form.

## 🏁 Example GitHub Repo Name
`eCourts_CauseList_Scraper_RakeshMalash`

---
### ⭐ Made by Rakesh Malash for Internship Submission
