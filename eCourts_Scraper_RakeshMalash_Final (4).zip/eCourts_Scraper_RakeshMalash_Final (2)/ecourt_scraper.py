#!/usr/bin/env python3
"""eCourts Scraper with PDF Output — by Rakesh Malash"""

import argparse
import requests
from bs4 import BeautifulSoup
import datetime
import json
import os
import logging
import pdfkit

logging.basicConfig(level=logging.INFO, format='[%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

BASE_URL = "https://services.ecourts.gov.in/ecourtindia_v6/"
OUTPUT_DIR = "ecourt_output"
os.makedirs(OUTPUT_DIR, exist_ok=True)
SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100 Safari/537.36"
})

REQUEST_TIMEOUT = 15

def date_for_flag(today: bool, tomorrow: bool) -> datetime.date:
    if today:
        return datetime.date.today()
    if tomorrow:
        return datetime.date.today() + datetime.timedelta(days=1)
    return datetime.date.today()

def save_json(obj, filename):
    path = os.path.join(OUTPUT_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    logger.info("Saved JSON: %s", path)

def fetch_cause_list_for_date(date_obj: datetime.date):
    date_str = date_obj.strftime("%d-%m-%Y")
    logger.info("Fetching cause list for date: %s", date_str)
    url = BASE_URL
    try:
        r = SESSION.get(url, timeout=REQUEST_TIMEOUT)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, "html.parser")
        return soup
    except Exception as e:
        logger.error("Error fetching cause list: %s", e)
        return None

def cli_download_causelist(args):
    target_date = date_for_flag(args.today, args.tomorrow)
    soup = fetch_cause_list_for_date(target_date)
    if not soup:
        logger.error("Failed to fetch cause list for %s", target_date)
        return

    date_str = target_date.isoformat()
    html_path = os.path.join(OUTPUT_DIR, f"cause_list_{date_str}.html")
    json_path = os.path.join(OUTPUT_DIR, f"cause_list_{date_str}.json")
    pdf_path = os.path.join(OUTPUT_DIR, f"cause_list_{date_str}.pdf")

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(soup.prettify())
    logger.info("Saved HTML cause list: %s", html_path)

    rows = soup.select("tr")
    cases = []
    for tr in rows:
        cols = [c.get_text(strip=True) for c in tr.find_all(["td","th"])]
        if cols:
            cases.append({"raw_columns": cols})
    save_json(cases, f"cause_list_{date_str}.json")

    try:
        pdfkit.from_file(html_path, pdf_path)
        logger.info("Saved PDF cause list: %s", pdf_path)
    except Exception as e:
        logger.warning("PDF generation failed: %s", e)

def parse_args():
    p = argparse.ArgumentParser(description="eCourts Cause List Scraper with PDF Output")
    group = p.add_mutually_exclusive_group(required=True)
    group.add_argument("--cnr", help="Search by CNR (dummy if only cause list needed)")
    group.add_argument("--case", nargs=3, metavar=("TYPE","NUMBER","YEAR"), help="Search by case details")
    p.add_argument("--today", action="store_true", help="Today's cause list")
    p.add_argument("--tomorrow", action="store_true", help="Tomorrow's cause list")
    p.add_argument("--causelist", action="store_true", help="Download cause list")
    return p.parse_args()

def main():
    args = parse_args()
    if args.causelist:
        cli_download_causelist(args)
    else:
        logger.info("Use --causelist to download today's cause list")

if __name__ == "__main__":
    main()
