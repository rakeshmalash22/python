#!/usr/bin/env python3
"""ecourt_scraper.py

CLI tool to search eCourts cause lists for a CNR or case details, check if the case is
listed today or tomorrow, optionally download case PDF and/or entire cause list.

Notes:
- The eCourts website structure may change. Selectors used here are generic and
  commented so you can adapt them quickly after inspecting the site HTML.
- This script tries to be defensive (timeouts, retries, error handling).
"""

import argparse
import requests
from bs4 import BeautifulSoup
import datetime
import json
import os
import sys
import logging
from typing import Optional, Dict, Any

# Configure logging
logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0 Safari/537.36"
})

# --- Configuration ---
# Base URL for eCourts. If the site uses JS to load content, you may need to use
# Selenium or an API endpoint. Update this if you discover the proper endpoint.
BASE_URL = "https://services.ecourts.gov.in/ecourtindia_v6/"

# Default output folder
OUTPUT_DIR = "ecourt_output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Timeout for requests
REQUEST_TIMEOUT = 15

def date_for_flag(today: bool, tomorrow: bool) -> datetime.date:
    if today:
        return datetime.date.today()
    if tomorrow:
        return datetime.date.today() + datetime.timedelta(days=1)
    # default to today
    return datetime.date.today()

def save_json(obj: Any, filename: str):
    path = os.path.join(OUTPUT_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    logger.info("Saved: %s", path)

def download_file(url: str, dest_path: str):
    try:
        r = SESSION.get(url, timeout=REQUEST_TIMEOUT)
        r.raise_for_status()
        with open(dest_path, "wb") as f:
            f.write(r.content)
        logger.info("Downloaded: %s", dest_path)
        return True
    except Exception as e:
        logger.error("Failed to download %s — %s", url, e)
        return False

def fetch_cause_list_for_date(date_obj: datetime.date) -> Optional[BeautifulSoup]:
    """Fetch the cause list page for the given date and return parsed BeautifulSoup.

    NOTE: The real eCourts site often requires searching by court/state. If you need
    an entire cause list for a particular court or state, adapt this function to
    call the appropriate endpoint (POST/GET) and form fields.
    """
    date_str = date_obj.strftime("%d-%m-%Y")
    logger.info("Fetching cause list for date: %s", date_str)

    # Example placeholder URL — you should inspect eCourts and replace if needed.
    # This attempts to open the generic cause-list page and will parse HTML.
    url = BASE_URL  # replace with exact endpoint if known

    try:
        r = SESSION.get(url, timeout=REQUEST_TIMEOUT)
        r.raise_for_status()
    except Exception as e:
        logger.error("Request failed: %s", e)
        return None

    soup = BeautifulSoup(r.text, "html.parser")
    return soup

def find_case_in_soup_by_cnr(soup: BeautifulSoup, cnr: str, date_obj: datetime.date) -> Optional[Dict]:
    """Search parsed cause-list HTML for a CNR. Adapt selectors according to the site.

    Returns dict with keys: serial_no, court_name, pdf_url (optional)
    """
    logger.info("Searching for CNR: %s", cnr)
    # NOTE: The selectors below are placeholders. Inspect eCourts cause list HTML and update:
    # e.g., each case might be in a table row <tr class=\"case-row\"> with columns for serial, CNR, party, court
    rows = soup.select("tr")  # naive — replace with a more specific selector
    for tr in rows:
        text = tr.get_text(separator="|").strip()
        if cnr.lower() in text.lower():
            # attempt to extract serial and court name heuristically
            cols = [c.get_text(strip=True) for c in tr.find_all(["td","th"])]
            serial = cols[0] if len(cols) > 0 else ""
            court_name = cols[1] if len(cols) > 1 else ""
            # look for pdf link
            a = tr.find("a", href=True)
            pdf_url = None
            if a and a["href"].lower().endswith(".pdf"):
                pdf_url = a["href"]
            result = {"cnr": cnr, "serial": serial, "court_name": court_name, "pdf_url": pdf_url, "date": date_obj.isoformat()}
            logger.info("Found: %s", result)
            return result
    logger.info("CNR not found in parsed HTML")
    return None

def find_case_in_soup_by_components(soup: BeautifulSoup, case_type: str, number: str, year: str, date_obj: datetime.date) -> Optional[Dict]:
    logger.info("Searching for Case: %s %s/%s", case_type, number, year)
    rows = soup.select("tr")
    for tr in rows:
        text = tr.get_text(separator="|").strip()
        # simplistic match — customize to site's exact formatting
        if case_type.lower() in text.lower() and number in text and year in text:
            cols = [c.get_text(strip=True) for c in tr.find_all(["td","th"])]
            serial = cols[0] if len(cols) > 0 else ""
            court_name = cols[1] if len(cols) > 1 else ""
            a = tr.find("a", href=True)
            pdf_url = None
            if a and a["href"].lower().endswith(".pdf"):
                pdf_url = a["href"]
            return {"case_type": case_type, "number": number, "year": year, "serial": serial, "court_name": court_name, "pdf_url": pdf_url, "date": date_obj.isoformat()}
    return None

def cli_search(args):
    target_date = date_for_flag(args.today, args.tomorrow)

    # Fetch cause-list HTML (or API response) for the date
    soup = fetch_cause_list_for_date(target_date)
    if not soup:
        logger.error("Failed to fetch cause list for %s", target_date)
        return

    found = None
    if args.cnr:
        found = find_case_in_soup_by_cnr(soup, args.cnr, target_date)
    else:
        found = find_case_in_soup_by_components(soup, args.case_type, args.number, args.year, target_date)

    if found:
        print(json.dumps(found, indent=2, ensure_ascii=False))
        save_json(found, f"search_result_{target_date.isoformat()}.json")
        if args.download_pdf and found.get("pdf_url"):
            pdf_url = found["pdf_url"]
            # make absolute URL if necessary
            if pdf_url.startswith("/"):
                pdf_url = BASE_URL.rstrip("/") + pdf_url
            fname = os.path.join(OUTPUT_DIR, os.path.basename(pdf_url))
            download_file(pdf_url, fname)
    else:
        print("Case not found for date:", target_date.isoformat())

def cli_download_causelist(args):
    target_date = date_for_flag(args.today, args.tomorrow)
    soup = fetch_cause_list_for_date(target_date)
    if not soup:
        logger.error("Failed to fetch cause list for %s", target_date)
        return

    # Heuristic: save the entire HTML / text as cause list
    date_str = target_date.isoformat()
    html_path = os.path.join(OUTPUT_DIR, f"cause_list_{date_str}.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(soup.prettify())
    logger.info("Saved cause list HTML: %s", html_path)

    # Optionally attempt to parse visible case entries into JSON
    cases = []
    rows = soup.select("tr")
    for tr in rows:
        cols = [c.get_text(strip=True) for c in tr.find_all(["td","th"])]
        if cols:
            cases.append({"raw_columns": cols})
    save_json(cases, f"cause_list_{date_str}.json")

def parse_args():
    p = argparse.ArgumentParser(description="eCourts cause-list scraper (CLI)")
    group = p.add_mutually_exclusive_group(required=True)
    group.add_argument("--cnr", help="Search by CNR number (e.g., ABCD0123456789)")
    group.add_argument("--case", nargs=3, metavar=("TYPE","NUMBER","YEAR"), help="Search by case components: TYPE NUMBER YEAR")

    p.add_argument("--today", action="store_true", help="Search for today (default if neither today/tomorrow given)")
    p.add_argument("--tomorrow", action="store_true", help="Search for tomorrow")
    p.add_argument("--download-pdf", action="store_true", help="If case PDF link is found, download it")
    p.add_argument("--causelist", action="store_true", help="Download entire cause list for the date")
    p.add_argument("--output-dir", default=OUTPUT_DIR, help="Directory to save outputs")
    return p.parse_args()

def main():
    args = parse_args()
    # if --case was used, unpack
    if args.case:
        args.case_type, args.number, args.year = args.case
    else:
        args.case_type = args.number = args.year = None

    global OUTPUT_DIR
    OUTPUT_DIR = args.output_dir
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    if args.causelist:
        cli_download_causelist(args)
    else:
        cli_search(args)

if __name__ == "__main__":
    main()
