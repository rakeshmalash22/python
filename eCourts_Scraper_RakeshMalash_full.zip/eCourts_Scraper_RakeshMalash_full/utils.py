# utils.py - optional helpers for the eCourts scraper

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

def make_session_with_retries(retries: int = 3, backoff_factor: float = 0.3) -> requests.Session:
    s = requests.Session()
    retry = Retry(total=retries, backoff_factor=backoff_factor, status_forcelist=[429,500,502,503,504])
    adapter = HTTPAdapter(max_retries=retry)
    s.mount("https://", adapter)
    s.mount("http://", adapter)
    s.headers.update({"User-Agent": "ecourt-scraper/1.0"})
    return s
