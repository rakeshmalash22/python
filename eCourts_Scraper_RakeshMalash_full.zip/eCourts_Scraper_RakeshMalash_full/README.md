# eCourts Scraper — CLI

This project is a CLI tool that helps search eCourts cause lists (today/tomorrow) for
cases by **CNR** or **(Case Type, Number, Year)**. It can optionally download case PDFs
and save outputs as JSON/HTML.

## Features
- Search by CNR or Case components
- Check listings for **today** or **tomorrow**
- Print serial number and court name if found
- Optionally download case PDF (if PDF link is present in the listing)
- Optionally save entire cause list (HTML + JSON)
- JSON/text outputs stored in `ecourt_output/`

## Setup
1. Create a virtual environment (recommended):

```bash
python -m venv .venv
source .venv/bin/activate   # Linux/macOS
.\.venv\Scripts\activate  # Windows
```

2. Install requirements:

```bash
pip install -r requirements.txt
```

3. Run examples (see Usage)

## Usage examples

- Search by CNR for today:

```bash
python ecourt_scraper.py --cnr "ABCD0123456789" --today
```

- Search by case components for tomorrow and download PDF if found:

```bash
python ecourt_scraper.py --case CR 1234 2024 --tomorrow --download-pdf
```

- Download the entire cause list for today:

```bash
python ecourt_scraper.py --cnr dummy --today --causelist
```

(Use `--cnr dummy` because the script requires one of the exclusive group flags — if you only
want cause list, you may adapt the argument parser to allow causelist-only runs.)

## Important notes & troubleshooting
- The eCourts site frequently uses JS and dynamic endpoints. If you find that the script
  returns no results while the website shows results, inspect the network tab in browser
  developer tools and find the exact API or endpoint used by eCourts to fetch cause lists.
  Then replace `fetch_cause_list_for_date()` URL and parsing logic accordingly.
- If the site requires JavaScript rendering, consider using `selenium` or `playwright` and
  updating the script.
- The HTML selectors in the parsing functions are intentionally generic. Update them after
  inspecting the live cause list HTML structure.

## What to submit (for internship)
- `ecourt_scraper.py` — main script
- `utils.py` — optional helpers
- `requirements.txt`
- `README.md` — setup & usage

Zip these files into `eCourts_Scraper_<yourname>.zip` or push to GitHub.

---

## Next steps / Bonus (recommended)
1. Add unit tests for parsing functions using saved example HTML files.
2. Add a `--court` or `--state` argument to fetch cause lists for a particular court.
3. Add a small Streamlit UI for nicer manual usage (optional bonus).
4. If required, add Selenium fallback when requests-based fetching fails.
